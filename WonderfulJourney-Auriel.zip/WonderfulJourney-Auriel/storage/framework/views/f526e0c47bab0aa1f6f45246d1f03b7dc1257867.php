

<style>
    .boxShadow{
        transition: 1s
    }
    .boxShadow:hover{
        transform: scale(1.02)
    }
</style>

<?php $__env->startSection('content'); ?>
    
    <div class="container p-4 border rounded shadow boxShadow">

        <div class="row">
            <div class="col-md-4">
                <img class="img img-thumbnail" src="<?php echo e(asset("image/$article->image")); ?>" alt="...">
            </div>
            <div class="col-md-8">
                <p style="font-size: 2rem"><?php echo e($article->title); ?></p>
                <p class="text-muted">Author: <?php echo e($article->user->name); ?></p>
                <p><?php echo e($article->description); ?></p>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebProgramming\resources\views/detailPage.blade.php ENDPATH**/ ?>