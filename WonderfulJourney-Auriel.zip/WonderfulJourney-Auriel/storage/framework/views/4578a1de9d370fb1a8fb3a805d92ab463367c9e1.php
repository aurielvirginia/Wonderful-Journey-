

<style>
    .cardHover {
        transition: 0.3s;
        box-shadow: 5px 10px rgb(0, 157, 255);
    }

    .cardHover:hover {
        transform: scale(1.03);
        box-shadow: 7px 12px rgb(0, 87, 142);
    }

</style>

<?php $__env->startSection('content'); ?>

    <div class="container">

        <?php if(auth()->guard()->guest()): ?>

            <p class="display-4 text-center text-light"><?php echo e($category->name); ?></p>
            <div class="row">
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 my-3">
                        <a class="text-decoration-none text-dark" href="/detailPage/<?php echo e($item->id); ?>">
                            <div class="card cardHover">
                                <img style="height: 15rem" src="<?php echo e(asset("image/$item->image")); ?>" class="card-img-top"
                                    alt="...">
                                <div class="card-body">
                                    <h5 class="card-title text-truncate"><?php echo e($item->title); ?></h5>
                                    <p class="card-text text-truncate"><?php echo e($item->description); ?></p>
                                </div>
                                <div class="card-footer">
                                    <p class="card-text text-truncate">Category: <a
                                            href="/categoryPage/<?php echo e($item->id); ?>"><?php echo e($item->category->name); ?></a>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php else: ?>

            <?php if(Auth::user()->role == 'Member'): ?>

                <p class="display-4 text-center text-light"><?php echo e($category->name); ?></p>

                <div class="row">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 my-3">
                            <a class="text-decoration-none text-dark" href="/detailPage/<?php echo e($item->id); ?>">
                                <div class="card cardHover">
                                    <img style="height: 15rem" src="<?php echo e(asset("image/$item->image")); ?>" class="card-img-top"
                                        alt="...">
                                    <div class="card-body">
                                        <h5 class="card-title text-truncate"><?php echo e($item->title); ?></h5>
                                        <p class="card-text text-truncate"><?php echo e($item->description); ?></p>
                                    </div>
                                    <div class="card-footer">
                                        <p class="card-text text-truncate">Category: <a
                                                href="/categoryPage/<?php echo e($item->id); ?>"><?php echo e($item->category->name); ?></a></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>


        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Backup User\Downloads\WonderfulJourney-Auriel\resources\views/categoryPage.blade.php ENDPATH**/ ?>