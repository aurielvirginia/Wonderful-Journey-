@extends('layouts.app')

@section('content')
    <div class="container">

        <div class="display-4 text-center text-light">Update Profile</div>

        <div>
            <form method="POST" action="/updatedProfile">
                @csrf

                <div>
                    <label for="name" class="col-form-label text-md-right text-light">{{ __('Name') }}</label>

                    <div>
                        <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name"
                            value="{{ $member->name }}" required autocomplete="name" autofocus>

                        @error('name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div>
                    <label for="email" class="col-form-label text-md-right text-light">{{ __('E-Mail Address') }}</label>

                    <div>
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ $member->email }}" required autocomplete="email">

                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div>
                    <label for="phone_number" class="col-form-label text-md-right text-light">{{ __('Phone Number') }}</label>

                    <div>
                        <input id="phone_number" type="text"
                            class="form-control @error('phone_number') is-invalid @enderror" name="phone_number"
                            value="{{ $member->phonenumber }}" required autocomplete="phone_number">

                        @error('phone_number')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="my-4">
                    <button type="submit" class="btn btn-primary btn-block">
                        Update
                    </button>
                </div>

            </form>
        </div>
    </div>
@endsection
