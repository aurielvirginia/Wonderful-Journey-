@extends('layouts.app')

<style>
    .boxShadow{
        transition: 1s
    }
    .boxShadow:hover{
        transform: scale(1.02)
    }
</style>

@section('content')
    
    <div class="container p-4 border rounded shadow boxShadow">

        <div class="row">
            <div class="col-md-4">
                <img class="img img-thumbnail" src="{{ asset("image/$article->image") }}" alt="...">
            </div>
            <div class="col-md-8">
                <p class="font-size: 2rem text-light">{{ $article->title }}</p>
                <p class="text-light">Author: {{ $article->user->name }}</p>
                <p class="text-light">{{ $article->description }}</p>
            </div>
        </div>

    </div>

@endsection