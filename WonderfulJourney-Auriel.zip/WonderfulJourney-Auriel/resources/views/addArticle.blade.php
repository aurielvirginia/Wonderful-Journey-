@extends('layouts.app')

@section('content')
    <div class="container">

        <div class="display-4 text-center text-light">Add Article</div>

        <div>
            <form method="POST" action="/addedArticle" enctype="multipart/form-data">
                @csrf

                <div>
                    <label for="title" class="col-form-label text-md-right text-light">{{ __('Title') }}</label>

                    <div>
                        <input id="title" type="text" class="form-control @error('title') is-invalid @enderror" name="title"
                            value="" required autocomplete="title" autofocus>

                        @error('title')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div>
                    <label for="category" class="col-form-label text-md-right text-light">{{ __('Category') }}</label>

                    <div>
                        <select name="category" class="form-control @error('category') is-invalid @enderror" id="">
                            @foreach ($categories as $item)
                                <option value="{{ $item->id }}">{{ $item->name }}</option>
                            @endforeach
                        </select>

                        @error('category')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div>
                    <label for="description" class="col-form-label text-md-right text-light">{{ __('Description') }}</label>

                    <div>
                        <textarea name="description" id="" cols="30" rows="5"
                            class="form-control @error('description') is-invalid @enderror" name="description" value=""
                            required autocomplete="description"></textarea>

                        @error('description')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div>
                    <label for="image" class="col-form-label text-md-right text-light">{{ __('Image') }}</label>

                    <div>
                        <input id="image" type="file" class="form-control @error('image') is-invalid @enderror" name="image"
                            value="" required autocomplete="image" autofocus>

                        @error('image')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                </div>

                <div class="my-4">
                    <button type="submit" class="btn btn-primary btn-block">
                        Add
                    </button>
                </div>

            </form>
        </div>
    </div>
@endsection
