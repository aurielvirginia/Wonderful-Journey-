@extends('layouts.app')

<style>
    .cardHover {
        transition: 0.3s;
        box-shadow: 5px 10px rgb(0, 157, 255);
    }

    .cardHover:hover {
        transform: scale(1.03);
        box-shadow: 7px 12px rgb(0, 87, 142);
    }

</style>

@section('content')

    <div class="container">
        <p class="display-4 text-center text-light">Your Blogs</p>
        <a href="/addArticle" class="btn btn-success">Add an Article</a>
        <div class="row">
            @foreach ($articles as $item)
                <div class="col-lg-4 my-3">
                    <div class="card cardHover">
                        <img style="height: 15rem" src="{{ asset("image/$item->image") }}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title text-truncate">{{ $item->title }}</h5>
                            <p class="card-text text-truncate">{{ $item->description }}</p>
                            <p class="card-text text-truncate">Category: {{ $item->category->name }}</p>
                        </div>
                        <div class="card-footer btn-group">
                            <a href="/deleteBlog/{{ $item->id }}" class="btn btn-danger">Delete Blog</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

@endsection
