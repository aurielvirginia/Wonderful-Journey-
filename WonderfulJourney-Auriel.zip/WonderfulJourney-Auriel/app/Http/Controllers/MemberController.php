<?php

namespace App\Http\Controllers;

use App\Article;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MemberController extends Controller
{
    public function viewUpdate(){

        $member = Auth::user();
        return view('editProfile')->with('member',$member);
    }

    public function updateProfile(Request $request){

        $member = Auth::user();

        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone_number' => 'required|numeric',
        ]);
        
        DB::table('users')->where('id',$member->id)->update([
            'name' => $request->name,
            'email' => $request->email,
            'phonenumber' => $request->phone_number
        ]);

        return redirect('/');
    }

    public function viewBlogs(){

        $member = Auth::user();
        $articles = Article::where('userid',$member->id)->get();
        return view('yourBlogs')->with('articles',$articles);
    }

    public function deleteBlog($articleID){

        DB::table('articles')->where('id',$articleID)->delete();

        return redirect('/yourBlogs');
    }

}
