<?php

namespace App\Http\Controllers;

use App\Article;
use App\Category;
use App\User;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $users = User::where('role', 'Member')->get();
        $articles = Article::all();
        return view('home')->with('articles',$articles)->with('users',$users);
    }

    public function articleDetail($articleID){
        
        $article = Article::find($articleID);
        return view('detailPage')->with('article', $article);
    }

    public function categoryPage($categoryID){
        $articles = Article::where('categoryid',$categoryID)->get();
        $category = Category::find($categoryID);
        return view('categoryPage')->with('category',$category)->with('articles',$articles);
    }
}
