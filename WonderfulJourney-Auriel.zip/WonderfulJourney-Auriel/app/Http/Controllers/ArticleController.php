<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ArticleController extends Controller
{
    public function view(){

        $categories = Category::all();
        return view('addArticle')->with('categories',$categories);
    }

    public function add(Request $request){

        $user = Auth::user();

        $request->validate([
            'image' => 'required|mimes:jpg,jpeg,png'
        ]);

        $file = $request->file('image');
        $file->move('image/', $request->image->getClientOriginalName());

        DB::table('articles')->insert([
            'title' => $request->title,
            'description' => $request->description,
            'image' => $request->image->getClientOriginalName(),
            'userid' => $user->id,
            'categoryid' => $request->category
        ]);

        return redirect('/');
    }
}
