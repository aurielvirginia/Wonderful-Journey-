<?php

use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
        [
            'name' => 'Riel',
            'email' => 'aurielvirginia@binus.ac.id',
            'phonenumber' => '08978564842',
            'role' => 'Admin',
            'password' => bcrypt('12admin'),
        ],
        [
            'name' => 'Handra',
            'email' => 'Handra@gmail.com',
            'phonenumber' => '081387587749',
            'role' => 'Users',
            'password' => bcrypt('12user'),
        ]
        ]);
    }
}
