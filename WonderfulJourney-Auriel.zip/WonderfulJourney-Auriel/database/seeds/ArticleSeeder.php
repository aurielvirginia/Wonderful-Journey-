<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('articles')->insert([
        [
            'userid' => 2,
            'categoryid' => 1,
            'title' => 'Mendaki Gunung Kilimanjaro',
            'description' => 'Puncak Kilimanjaro sekaligus merupakan puncak tertinggi di Afrika, dengan ketinggian 5.895 meter di atas permukaan laut. Gunung ini juga disebut Kilima Dscharo atau Oldoinyo Oibor yang berarti gunung putih dalam bahasa Masai.',
            'image' => 'kilimanjaro.jpg'
        ],
        [
            'userid' => 3,
            'categoryid' => 1,
            'title' => 'Mendaki Gunung Kilimanjaro',
            'description' => 'Puncak Kilimanjaro sekaligus merupakan puncak tertinggi di Afrika, dengan ketinggian 5.895 meter di atas permukaan laut. Gunung ini juga disebut Kilima Dscharo atau Oldoinyo Oibor yang berarti gunung putih dalam bahasa Masai.',
            'image' => 'kilimanjaro.jpg'
        ],
        [
            'userid' => 2,
            'categoryid' => 2,
            'title' => 'Pantai Marina Khas Semarang',
            'description' => 'Pantai menjadi salah satu pilihan destinasi favorit, untuk rekreasi dan bersenang-senang menyegarkan diri. Adalah Pantai Marina dan Pantai Tirang salah satu Pantai populer yang menawan di Semarang.Namun kali ini kami akan mengulas mengenai Pantai Marina. Pantai ini sangat terkenal di kalangan masyarakat kota Semarang dan sekitarnya. Pantai Marina Semarang kerap kali menjadi bagian dari daftar wisata Semarang yang wajib dikunjungi.',
            'image' => 'marina.jpg'
        ],
        [
            'userid' => 3,
            'categoryid' => 2,
            'title' => 'Pantai Marina Khas Semarang',
            'description' => 'Pantai menjadi salah satu pilihan destinasi favorit, untuk rekreasi dan bersenang-senang menyegarkan diri. Adalah Pantai Marina dan Pantai Tirang salah satu Pantai populer yang menawan di Semarang.Namun kali ini kami akan mengulas mengenai Pantai Marina. Pantai ini sangat terkenal di kalangan masyarakat kota Semarang dan sekitarnya. Pantai Marina Semarang kerap kali menjadi bagian dari daftar wisata Semarang yang wajib dikunjungi.',
            'image' => 'marina.jpg'
        ],
        [
            'userid' => 2,
            'categoryid' => 3,
            'title' => 'Negara Afrika',
            'description' => 'Afrika adalah benua terbesar kedua di dunia dan kedua terbanyak penduduknya setelah Asia. Dengan luas wilayah 30.224.050 km² termasuk pulau-pulau yang berdekatan, Afrika meliputi 20,3% dari seluruh total daratan Bumi. Dengan 800 juta penduduk di 54 negara, benua ini merupakan tempat bagi sepertujuh populasi dunia',
            'image' => 'afrika.jpg'
        ],
        [
            'userid' => 3,
            'categoryid' => 3,
            'title' => 'Negara Afrika',
            'description' => 'Afrika adalah benua terbesar kedua di dunia dan kedua terbanyak penduduknya setelah Asia. Dengan luas wilayah 30.224.050 km² termasuk pulau-pulau yang berdekatan, Afrika meliputi 20,3% dari seluruh total daratan Bumi. Dengan 800 juta penduduk di 54 negara, benua ini merupakan tempat bagi sepertujuh populasi dunia',
            'image' => 'afrika.jpg'
        ],
        ]);
        

    }
}
